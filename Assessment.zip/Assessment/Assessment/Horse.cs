using System;

namespace Assessment;

public class Horse
{
    private string _nameHorse = "";
    private DateOnly _birthDateHorse;
    private string _horseID = "";

    public string NameHorse 
    { 
        get => _nameHorse;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                throw new ArgumentException("The horse name cannot be empty");
            }
            _nameHorse = value; 
        }
    }

    public DateOnly BirthDateHorse { get => _birthDateHorse; set => _birthDateHorse = value; }
    public string HorseID 
    { 
        get => _horseID;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                throw new ArgumentException ("The horse ID cannot be empty.");
            }
            _horseID = value;
        } 
    }

    public Horse(string nameHorse, DateOnly birthDateHorse, string horseID)
    {
        NameHorse = nameHorse;
        BirthDateHorse = birthDateHorse;
        HorseID = horseID;
    }

    public override string ToString()
    {
        return $"Horse Name: {NameHorse}, Birth Date: {BirthDateHorse}, Horse ID: {HorseID}";
    }
}
