﻿namespace Assessment
{
    class Program
    {
        static void Main(string[] args)
        {
            bool running = true;
            RaceEvent raceEvent = null;
            while (running)
            {
                Console.WriteLine("Choose an action:");
                Console.WriteLine("1. Create a new race event");
                Console.WriteLine("2. Add a horse to an existing race");
                Console.WriteLine("3. Display event details");
                Console.WriteLine("4. Exit");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        raceEvent = CreateNewRaceEvent();
                        break;

                    case "2":
                        if (raceEvent == null)
                        {
                            Console.WriteLine("No event has been created yet. Please create an event first.");
                        }
                        else
                        {
                            AddHorseToRace(raceEvent);
                        }
                        break;

                    case "3":
                        if (raceEvent != null)
                        {
                            raceEvent.DisplayRaces();
                        }
                        else
                        {
                            Console.WriteLine("No event has been created yet.");
                        }
                        break;

                    case "4":
                        running = false;
                        Console.WriteLine("Exiting the program. Goodbye!");
                        break;

                    default:
                        Console.WriteLine("Invalid choice. Please select a valid option.");
                        break;
                }
            }
        }

        static RaceEvent CreateNewRaceEvent()
        {
            Console.WriteLine("Enter your event name:");
            string eventName = Console.ReadLine();

            Console.WriteLine("Enter your event location");
            string eventLocation = Console.ReadLine();

            Console.WriteLine("Enter how many races will take place at your event");
            int numberRaces;
            while (!int.TryParse(Console.ReadLine(), out numberRaces) || numberRaces <= 0)
            {
                Console.WriteLine("Your event must have at least one race.");
            }

            RaceEvent raceEvent = new RaceEvent(eventName, eventLocation, numberRaces);

            for (int i = 0; i < numberRaces; i++)
            {
                Console.WriteLine($"Enter the name of Race {i + 1}");
                string raceName = Console.ReadLine();

                if (string.IsNullOrEmpty(raceName))
                {
                    raceName = $"Race {i + 1}";
                }

                Console.WriteLine($"Enter the start time for Race {i + 1} (yyyy/mm/dd hh:mm) or press Enter to skip.");
                string startTimeInput = Console.ReadLine();
                DateTime? startTime = null;

                if (!string.IsNullOrEmpty(startTimeInput) && DateTime.TryParse(startTimeInput, out DateTime parsedStartTime))
                {
                    startTime = parsedStartTime;
                }

                raceEvent.AddRace(raceName, startTime);
            }

            Console.WriteLine($@"Race Event created! Name: {raceEvent.EventName}
            Location: {raceEvent.EventLocation}
            Number of Races: {raceEvent.NumberRaces}");

            return raceEvent;
        }

        static void AddHorseToRace(RaceEvent raceEvent)
        {
            Console.WriteLine("Enter the name of the race you want to add the horse to:");
            string raceNameInput = Console.ReadLine();

            Race chosenRace = raceEvent.Races.FirstOrDefault(r => r.RaceName == raceNameInput);

            if (chosenRace == null)
            {
                Console.WriteLine($"Race {raceNameInput} not found in the event.");
                return;
            }

            Console.WriteLine("What is the name of the horse you want to register for this race?");
            string horseName = Console.ReadLine();

            Console.WriteLine("Horse's Date of Birth (yyyy/mm/dd):");
            DateOnly birthDateHorse;
            while (!DateOnly.TryParse(Console.ReadLine(), out birthDateHorse))
            {
                Console.WriteLine("Please enter a valid date (yyyy/mm/dd)");
            }

            Console.WriteLine("Please enter the horse ID:");
            string horseID = Console.ReadLine();

            Horse horse = new Horse(horseName, birthDateHorse, horseID);

            if (chosenRace.RaceListHorses.Any(h => h.HorseID == horse.HorseID))
            {
                Console.WriteLine($"A horse with ID {horse.HorseID} is already registered for this race.");
            }
            else
            {
                chosenRace.RaceListHorses.Add(horse);
                Console.WriteLine($"Horse '{horse.NameHorse}' has been added to the race '{chosenRace.RaceName}'.");
            }
        }
    }
}
