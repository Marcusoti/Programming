using System;

namespace Assessment;

public class Race
{
    private string _raceName = "";
    private DateTime? _startTime;

    private List<Horse> _raceListHorses = new List<Horse>();

    public string RaceName 
    { 
        get => _raceName; 
        set
        {
            if (string.IsNullOrEmpty(value))
            {
                throw new ArgumentNullException("You must enter a race name");
            }
            _raceName = value;
        }
    }
    public DateTime? StartTime { get => _startTime; set => _startTime = value; }
    public List<Horse> RaceListHorses { get => _raceListHorses; set => _raceListHorses = value; }

    public Race (string raceName, DateTime? startTime = null)
    {
        RaceName = raceName;
        StartTime = startTime;
    }

    public override string ToString()
    {
        return $"Race Name: {RaceName}, Start Time {StartTime?.ToString() ?? "Not Set"}, Number of Horses: {RaceListHorses.Count}";
    }

    public void AddHorse (Horse horse)
    {
        if (horse == null)
        {
            throw new ArgumentException ($"You need to enter the information for the horse");
        }

        if (RaceListHorses.Any(h => h.HorseID == horse.HorseID))
        {
            throw new InvalidOperationException ($"A horse with ID {horse.HorseID} named {horse.NameHorse} has already been registered for this race");
        }

        RaceListHorses.Add(horse);
        Console.WriteLine("Your registration has been successful!");
    }

    public void DisplayHorses()
    {
        if (RaceListHorses.Count == 0)
        {
            Console.WriteLine("No horses are registered for this race.");
        }
        else
        {
            Console.WriteLine($"Horses registered for {RaceName}:");
            foreach (var horse in RaceListHorses)
            {
                Console.WriteLine($"- Horse Name: {horse.NameHorse}, Horse ID: {horse.HorseID}, Date of Birth: {horse.BirthDateHorse}");
            }
        }
    }
    
}
