using System;

namespace Assessment;

public class RaceEvent
{
    private string _eventName = "";
    private string _eventLocation = "";
    private int _numberRaces = 0;

    public List <Race> Races { get; private set; }


    public string EventName 
    {
        get => _eventName;
        
        set {
            while (string.IsNullOrEmpty(value))
            {
            Console.WriteLine("You need to enter an event name. Please try again.");
            value = Console.ReadLine();
            }
            _eventName = value;
            }
    }
    public string EventLocation 
    { 
        get => _eventLocation;
    
        set {
            while (string.IsNullOrEmpty(value))
            {
            Console.WriteLine("You need to enter an event location. Please try again.");
            value = Console.ReadLine();
            }
            _eventLocation = value;
            }
    }
    public int NumberRaces 
    {
        get => _numberRaces;
        
        set {
            while (value <= 0)
            {   
                Console.WriteLine("You need to enter a valid number of races (minimum 1). Please try again");
                value = int.Parse(Console.ReadLine());
            }
        _numberRaces = value;
        }
    }


    public RaceEvent (string eventName, string eventLocation, int numberRaces)
    {
        EventName = eventName;
        EventLocation = eventLocation;
        NumberRaces = numberRaces;
        Races = new List <Race> ();
    }

    public void AddRace (string raceName, DateTime? startTime = null)
    {
        if (string.IsNullOrEmpty(raceName))
        {
            raceName = $"Race {Races.Count + 1}";
        }

        if (startTime == null)
        {
            startTime = DateTime.Now;
        }
        Races.Add(new(raceName, startTime));
    }

    public void DisplayRaces()
    {
        Console.WriteLine($"\nEvent: {EventName}\nLocation: {EventLocation}");
        Console.WriteLine("Races:");
        foreach (var race in Races)
        {
            Console.WriteLine($"Race Name: {race.RaceName}, Start Time {race.StartTime}");
            race.DisplayHorses();
        }
    }
}
